import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ChevronDown, Github, Twitter, Linkedin, Mail } from 'lucide-react';

export default function Hero() {
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const taglineRef = useRef<HTMLDivElement>(null);
  const socialsRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate title letters
      const titleLetters = titleRef.current?.querySelectorAll('.letter');
      if (titleLetters) {
        gsap.fromTo(
          titleLetters,
          { y: 100, opacity: 0, rotateX: -90 },
          {
            y: 0,
            opacity: 1,
            rotateX: 0,
            duration: 1,
            stagger: 0.08,
            ease: 'back.out(1.7)',
            delay: 0.5,
          }
        );
      }

      // Animate subtitle
      gsap.fromTo(
        subtitleRef.current,
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 1, delay: 1.5, ease: 'power3.out' }
      );

      // Animate tagline
      gsap.fromTo(
        taglineRef.current,
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 1, delay: 1.8, ease: 'power3.out' }
      );

      // Animate socials
      gsap.fromTo(
        socialsRef.current?.children || [],
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, delay: 2.2, ease: 'power3.out' }
      );

      // Animate scroll indicator
      gsap.fromTo(
        scrollRef.current,
        { opacity: 0 },
        { opacity: 1, duration: 1, delay: 2.8 }
      );

      // Bounce animation for scroll indicator
      gsap.to(scrollRef.current, {
        y: 10,
        duration: 1,
        repeat: -1,
        yoyo: true,
        ease: 'power1.inOut',
      });
    });

    return () => ctx.revert();
  }, []);

  const titleText = 'COULDFISH';

  return (
    <section className="min-h-screen flex flex-col items-center justify-center relative px-4">
      {/* Main content */}
      <div className="text-center z-10">
        {/* Name with 3D effect */}
        <h1
          ref={titleRef}
          className="text-6xl sm:text-8xl md:text-9xl font-black mb-6 perspective-1000"
          style={{ perspective: '1000px' }}
        >
          {titleText.split('').map((letter, index) => (
            <span
              key={index}
              className="letter inline-block"
              style={{
                background: 'linear-gradient(135deg, #00d4ff 0%, #8b5cf6 50%, #ff00ff 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                textShadow: '0 0 60px rgba(0, 212, 255, 0.5)',
              }}
            >
              {letter}
            </span>
          ))}
        </h1>

        {/* Subtitle */}
        <p
          ref={subtitleRef}
          className="text-xl sm:text-2xl md:text-3xl font-light text-white/90 mb-4 tracking-widest"
        >
          Creative Developer & Designer
        </p>

        {/* Tagline */}
        <div ref={taglineRef} className="flex flex-wrap justify-center gap-3 mb-8">
          {['React', 'Three.js', 'TypeScript', 'Node.js', 'UI/UX'].map((skill, index) => (
            <span
              key={index}
              className="px-4 py-2 rounded-full text-sm font-medium backdrop-blur-md bg-white/10 border border-white/20 text-white/80 hover:bg-white/20 hover:border-white/40 transition-all duration-300 hover:scale-105"
            >
              {skill}
            </span>
          ))}
        </div>

        {/* Social Links */}
        <div ref={socialsRef} className="flex justify-center gap-4">
          {[
            { icon: Github, href: '#', label: 'GitHub' },
            { icon: Twitter, href: '#', label: 'Twitter' },
            { icon: Linkedin, href: '#', label: 'LinkedIn' },
            { icon: Mail, href: '#', label: 'Email' },
          ].map((social, index) => (
            <a
              key={index}
              href={social.href}
              aria-label={social.label}
              className="w-12 h-12 rounded-full backdrop-blur-md bg-white/10 border border-white/20 flex items-center justify-center text-white/80 hover:bg-white/20 hover:border-white/40 hover:text-white hover:scale-110 transition-all duration-300"
            >
              <social.icon size={20} />
            </a>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        ref={scrollRef}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center text-white/60"
      >
        <span className="text-sm mb-2 tracking-wider">SCROLL</span>
        <ChevronDown size={24} />
      </div>

      {/* Gradient overlays */}
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-black/50 to-transparent pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black/50 to-transparent pointer-events-none" />
    </section>
  );
}
