import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const skills = [
  { name: 'React / Next.js', level: 95, color: '#00d4ff' },
  { name: 'TypeScript', level: 90, color: '#8b5cf6' },
  { name: 'Three.js / WebGL', level: 85, color: '#ff00ff' },
  { name: 'Node.js', level: 88, color: '#00d4ff' },
  { name: 'CSS / Tailwind', level: 92, color: '#8b5cf6' },
  { name: 'UI/UX Design', level: 80, color: '#ff00ff' },
];

const tools = [
  'VS Code', 'Figma', 'Git', 'Docker', 'AWS', 'Vercel',
  'Blender', 'Photoshop', 'Illustrator', 'Framer', 'Unity', 'Unreal'
];

export default function Skills() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const barsRef = useRef<HTMLDivElement>(null);
  const toolsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        titleRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Progress bars animation
      const bars = barsRef.current?.querySelectorAll('.progress-fill');
      if (bars) {
        bars.forEach((bar, index) => {
          const level = skills[index]?.level || 0;
          gsap.fromTo(
            bar,
            { width: '0%' },
            {
              width: `${level}%`,
              duration: 1.5,
              ease: 'power3.out',
              scrollTrigger: {
                trigger: bar,
                start: 'top 85%',
                toggleActions: 'play none none reverse',
              },
            }
          );
        });
      }

      // Skill labels animation
      const labels = barsRef.current?.querySelectorAll('.skill-item');
      if (labels) {
        gsap.fromTo(
          labels,
          { x: -30, opacity: 0 },
          {
            x: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: barsRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Tools animation
      const toolItems = toolsRef.current?.querySelectorAll('.tool-item');
      if (toolItems) {
        gsap.fromTo(
          toolItems,
          { scale: 0.8, opacity: 0 },
          {
            scale: 1,
            opacity: 1,
            duration: 0.5,
            stagger: 0.05,
            ease: 'back.out(1.7)',
            scrollTrigger: {
              trigger: toolsRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="min-h-screen py-20 px-4 sm:px-8 lg:px-16 relative"
    >
      <div className="max-w-5xl mx-auto">
        {/* Section Title */}
        <h2
          ref={titleRef}
          className="text-4xl sm:text-5xl md:text-6xl font-bold text-center mb-16"
        >
          <span
            style={{
              background: 'linear-gradient(135deg, #00d4ff 0%, #8b5cf6 50%, #ff00ff 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Skills & Tools
          </span>
        </h2>

        {/* Progress Bars */}
        <div ref={barsRef} className="space-y-6 mb-16">
          {skills.map((skill, index) => (
            <div key={index} className="skill-item">
              <div className="flex justify-between items-center mb-2">
                <span className="text-white font-medium text-lg">{skill.name}</span>
                <span className="text-white/60 font-mono">{skill.level}%</span>
              </div>
              <div className="h-3 rounded-full bg-white/10 overflow-hidden backdrop-blur-sm">
                <div
                  className="progress-fill h-full rounded-full relative"
                  style={{
                    width: '0%',
                    background: `linear-gradient(90deg, ${skill.color}, ${skill.color}88)`,
                    boxShadow: `0 0 20px ${skill.color}66`,
                  }}
                >
                  {/* Shimmer effect */}
                  <div
                    className="absolute inset-0 animate-pulse"
                    style={{
                      background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)',
                      animation: 'shimmer 2s infinite',
                    }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Tools Grid */}
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold text-white/90 mb-6">Tools I Use</h3>
        </div>
        <div
          ref={toolsRef}
          className="flex flex-wrap justify-center gap-3"
        >
          {tools.map((tool, index) => (
            <span
              key={index}
              className="tool-item px-5 py-2 rounded-full backdrop-blur-md bg-white/10 border border-white/20 text-white/80 font-medium hover:bg-white/20 hover:border-white/40 hover:scale-110 hover:text-white transition-all duration-300 cursor-default"
            >
              {tool}
            </span>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </section>
  );
}
