import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ExternalLink, Github } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const projects = [
  {
    title: 'Neon Dashboard',
    description: 'A futuristic analytics dashboard with real-time data visualization and 3D charts.',
    tags: ['React', 'Three.js', 'D3.js'],
    color: '#00d4ff',
    gradient: 'from-cyan-500/20 to-blue-500/20',
  },
  {
    title: 'Cyber Portfolio',
    description: 'Immersive portfolio website featuring WebGL effects and interactive 3D elements.',
    tags: ['Next.js', 'WebGL', 'GSAP'],
    color: '#ff00ff',
    gradient: 'from-purple-500/20 to-pink-500/20',
  },
  {
    title: 'Ethereal Commerce',
    description: 'Modern e-commerce platform with 3D product previews and smooth animations.',
    tags: ['React', 'Three.js', 'Stripe'],
    color: '#8b5cf6',
    gradient: 'from-violet-500/20 to-purple-500/20',
  },
  {
    title: 'Nova Chat',
    description: 'Real-time messaging app with beautiful UI and end-to-end encryption.',
    tags: ['Node.js', 'Socket.io', 'Redis'],
    color: '#00d4ff',
    gradient: 'from-cyan-500/20 to-teal-500/20',
  },
];

export default function Projects() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        titleRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards animation
      const cards = gridRef.current?.querySelectorAll('.project-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { y: 80, opacity: 0, rotateX: 20 },
          {
            y: 0,
            opacity: 1,
            rotateX: 0,
            duration: 1,
            stagger: 0.15,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: gridRef.current,
              start: 'top 75%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="min-h-screen py-20 px-4 sm:px-8 lg:px-16 relative"
    >
      <div className="max-w-6xl mx-auto">
        {/* Section Title */}
        <h2
          ref={titleRef}
          className="text-4xl sm:text-5xl md:text-6xl font-bold text-center mb-16"
        >
          <span
            style={{
              background: 'linear-gradient(135deg, #00d4ff 0%, #8b5cf6 50%, #ff00ff 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Featured Projects
          </span>
        </h2>

        {/* Projects Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
          style={{ perspective: '1000px' }}
        >
          {projects.map((project, index) => (
            <div
              key={index}
              className="project-card group relative rounded-2xl overflow-hidden backdrop-blur-md bg-white/5 border border-white/10 hover:border-white/30 transition-all duration-500"
              style={{
                transformStyle: 'preserve-3d',
                transform:
                  hoveredIndex === index
                    ? 'translateZ(30px) rotateX(-5deg)'
                    : 'translateZ(0) rotateX(0)',
                transition: 'transform 0.5s ease, border-color 0.3s ease',
              }}
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              {/* Background gradient */}
              <div
                className={`absolute inset-0 bg-gradient-to-br ${project.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
              />

              {/* Glow effect */}
              <div
                className="absolute -inset-px rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-sm"
                style={{
                  background: `linear-gradient(135deg, ${project.color}44, transparent)`,
                }}
              />

              {/* Content */}
              <div className="relative z-10 p-8">
                {/* Header */}
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-2xl font-bold text-white group-hover:text-white transition-colors">
                    {project.title}
                  </h3>
                  <div className="flex gap-2">
                    <a
                      href="#"
                      className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white/60 hover:bg-white/20 hover:text-white transition-all duration-300"
                      aria-label="View Code"
                    >
                      <Github size={18} />
                    </a>
                    <a
                      href="#"
                      className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white/60 hover:bg-white/20 hover:text-white transition-all duration-300"
                      aria-label="Live Demo"
                    >
                      <ExternalLink size={18} />
                    </a>
                  </div>
                </div>

                {/* Description */}
                <p className="text-white/60 mb-6 leading-relaxed">
                  {project.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="px-3 py-1 rounded-full text-sm font-medium backdrop-blur-sm bg-white/10 text-white/70 border border-white/10"
                      style={{
                        boxShadow: `0 0 10px ${project.color}22`,
                      }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Bottom accent line */}
              <div
                className="absolute bottom-0 left-0 h-1 w-0 group-hover:w-full transition-all duration-700 ease-out"
                style={{
                  background: `linear-gradient(90deg, ${project.color}, transparent)`,
                }}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
