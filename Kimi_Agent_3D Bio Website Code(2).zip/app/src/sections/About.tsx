import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Code2, Palette, Sparkles, Zap } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const features = [
  {
    icon: Code2,
    title: 'Clean Code',
    description: 'Writing maintainable, efficient, and well-documented code that stands the test of time.',
    color: '#00d4ff',
  },
  {
    icon: Palette,
    title: 'Beautiful Design',
    description: 'Crafting visually stunning interfaces that captivate users and enhance experiences.',
    color: '#ff00ff',
  },
  {
    icon: Zap,
    title: 'Performance',
    description: 'Optimizing every millisecond to deliver lightning-fast applications.',
    color: '#8b5cf6',
  },
  {
    icon: Sparkles,
    title: 'Innovation',
    description: 'Pushing boundaries with cutting-edge technologies and creative solutions.',
    color: '#00d4ff',
  },
];

export default function About() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        titleRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Text animation
      gsap.fromTo(
        textRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          delay: 0.2,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: textRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards animation
      const cards = cardsRef.current?.querySelectorAll('.feature-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { y: 60, opacity: 0, rotateY: -15 },
          {
            y: 0,
            opacity: 1,
            rotateY: 0,
            duration: 0.8,
            stagger: 0.15,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 75%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="min-h-screen py-20 px-4 sm:px-8 lg:px-16 relative"
    >
      <div className="max-w-6xl mx-auto">
        {/* Section Title */}
        <h2
          ref={titleRef}
          className="text-4xl sm:text-5xl md:text-6xl font-bold text-center mb-8"
        >
          <span
            style={{
              background: 'linear-gradient(135deg, #00d4ff 0%, #8b5cf6 50%, #ff00ff 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            About Me
          </span>
        </h2>

        {/* Description */}
        <div ref={textRef} className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-lg sm:text-xl text-white/80 leading-relaxed">
            I'm a passionate developer who transforms ideas into immersive digital experiences.
            With expertise in modern web technologies and 3D graphics, I create applications
            that not only function flawlessly but also leave lasting impressions.
          </p>
        </div>

        {/* Feature Cards */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {features.map((feature, index) => (
            <div
              key={index}
              className="feature-card group relative p-6 rounded-2xl backdrop-blur-md bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/30 transition-all duration-500 hover:scale-105 hover:-translate-y-2"
              style={{ perspective: '1000px' }}
            >
              {/* Glow effect */}
              <div
                className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-30 transition-opacity duration-500 blur-xl"
                style={{
                  background: `radial-gradient(circle at center, ${feature.color}, transparent)`,
                }}
              />

              {/* Content */}
              <div className="relative z-10">
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center mb-4 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6"
                  style={{
                    background: `linear-gradient(135deg, ${feature.color}33, ${feature.color}11)`,
                    border: `1px solid ${feature.color}44`,
                  }}
                >
                  <feature.icon size={28} style={{ color: feature.color }} />
                </div>

                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-white transition-colors">
                  {feature.title}
                </h3>

                <p className="text-white/60 text-sm leading-relaxed">
                  {feature.description}
                </p>
              </div>

              {/* Corner accent */}
              <div
                className="absolute top-0 right-0 w-20 h-20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{
                  background: `linear-gradient(135deg, transparent 50%, ${feature.color}22 50%)`,
                  borderRadius: '0 16px 0 0',
                }}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
